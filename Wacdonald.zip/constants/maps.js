const GOOGLE_API_KEY = "AIzaSyDwGCt0MCaTvjs_khxp8of5J3B7GzRa4JE"

export default GOOGLE_API_KEY