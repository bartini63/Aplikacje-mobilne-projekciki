# Aplikacje Mobilne - Projekt
# Przedmiot: Aplikacje Mobline 1
# Temat - Aplikacja do zamawiania jedzenia
# Zespół: Bartosz Nowotnik, Michał Pędzik, Daniel Palak
